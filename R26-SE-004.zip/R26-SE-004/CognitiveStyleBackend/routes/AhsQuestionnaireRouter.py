from fastapi import APIRouter

from models.AhsQuestionnaireModel import (AHSIncomingPayload, AHSResponse)
from services.AHSQuestionnaireService import process_ahs_questionnaire_service


router = APIRouter()

router = APIRouter(prefix="/anaylticwholistic", tags=["QuestionRunner Gaze"])

# The updated router now enforces the AHSResponse model
@router.post("/ahsquestionnaire", response_model=AHSResponse, tags=["AhsQuestionnaire"])
async def save_ahs_questionnaire(payload: AHSIncomingPayload):
    return await process_ahs_questionnaire_service(payload)