from pydantic import BaseModel, Field
from typing import List
from datetime import datetime

class QuestionAnswer(BaseModel):
    questionNumber: int
    question: str
    value: int = Field(..., ge=1, le=5)

class AssistQuestionCreate(BaseModel):
    user_id: str  # Expecting 'user_id' from the frontend
    answers: List[QuestionAnswer]

class AssistQuestionResponse(BaseModel):
    id: str
    user_id: str  # Returning 'user_id'
    dominant_profile: str
    createdAt: datetime