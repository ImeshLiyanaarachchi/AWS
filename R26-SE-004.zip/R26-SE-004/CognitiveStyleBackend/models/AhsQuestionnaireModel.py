from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime

# Model 1: Receives the raw data from the React frontend
class AHSAnswerIncoming(BaseModel):
    questionId: int
    rawScore: int

class AHSIncomingPayload(BaseModel):
    userId: str
    answers: List[AHSAnswerIncoming]
    visualTaskData: Optional[Dict[str, Any]] = None

# Model 2: Clean response back to the frontend
class AHSResponse(BaseModel):
    id: str
    userId: str
    cognitiveStyle: str
    createdAt: datetime