from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class VVQAnswer(BaseModel):
    questionId: int
    rawScore: str

class VVQCreate(BaseModel):
    userId: str
    answers: List[VVQAnswer]
    visualTaskData: Optional[Dict[str, Any]] = None

# UPDATED: Stripped down to only the requested fields
class VVQResponse(BaseModel):
    id: str
    userId: str
    dominant_profile: str
    created_at: datetime