from datetime import datetime
from bson import ObjectId
from database.connection import assist_question_collection
import numpy as np
from sklearn.cluster import KMeans

# Map the question numbers to their respective scales based on the research paper[cite: 1]
DEEP_QUESTIONS = {2, 6, 10, 12, 15, 17}
STRATEGIC_QUESTIONS = {3, 5, 7, 9, 11, 13}
SURFACE_QUESTIONS = {1, 4, 8, 14, 16, 18}

async def create_assist_question(data: dict):
    # 1. Calculate the Raw Scores
    deep_score = 0
    strategic_score = 0
    surface_score = 0

    for answer in data.get("answers", []):
        q_num = answer.get("questionNumber")
        val = answer.get("value", 0)

        if q_num in DEEP_QUESTIONS:
            deep_score += val
        elif q_num in STRATEGIC_QUESTIONS:
            strategic_score += val
        elif q_num in SURFACE_QUESTIONS:
            surface_score += val

    # 2. Determine Dominant Profile
    scores = {
        "Deep Approach": deep_score,
        "Strategic Approach": strategic_score,
        "Surface Approach": surface_score
    }
    dominant_profile = max(scores, key=scores.get)

    # 3. Construct the final document
    # FIX: Use "user_id" to match the AssistQuestionCreate model's dump
    document_to_save = {
        "user_id": data.get("user_id"),
        "dominant_profile": dominant_profile,
        "createdAt": datetime.utcnow()
    }

    # 4. Save to Database
    result = await assist_question_collection.insert_one(document_to_save)

    # 5. Format the API response
    document_to_save["id"] = str(result.inserted_id)

    if "_id" in document_to_save:
        del document_to_save["_id"]

    return document_to_save

async def get_all_assist_questions():
    responses = []
    async for doc in assist_question_collection.find():
        doc["_id"] = str(doc["_id"])
        responses.append(doc)
    return responses


async def get_assist_questions_by_user(user_id: str):
    responses = []
    async for doc in assist_question_collection.find({"user_id": user_id}):
        doc["_id"] = str(doc["_id"])
        responses.append(doc)
    return responses


async def get_single_response(response_id: str):
    doc = await assist_question_collection.find_one({"_id": ObjectId(response_id)})
    if not doc:
        return None

    doc["_id"] = str(doc["_id"])
    return doc