# Assuming your db collection is initialized like this:from

from database.connection import (ahs_question_collection)
from datetime import datetime
from models.AhsQuestionnaireModel import (
AHSIncomingPayload )


async def process_ahs_questionnaire_service(payload: AHSIncomingPayload):
    # 1. Define reverse-scored questions
    reverse_scored_ids = {11, 13, 14, 15, 16, 18}
    total_score = 0

    # 2. Process answers to calculate the score (we will not save these)
    for ans in payload.answers:
        if ans.questionId in reverse_scored_ids:
            total_score += (8 - ans.rawScore)
        else:
            total_score += ans.rawScore

    # 3. Calculate average and determine Cognitive Style
    question_count = len(payload.answers)
    overall_average = round(total_score / question_count, 2) if question_count > 0 else 0

    cognitive_style = "Wholistic" if overall_average >= 4.0 else "Analytic"

    # 4. Prepare Final Document (PERSISTING ONLY THE ESSENTIALS)
    db_document = {
        "userId": payload.userId,
        "cognitiveStyle": cognitive_style,
        "createdAt": datetime.utcnow()
    }

    # 5. Save to MongoDB
    result = await ahs_question_collection.insert_one(db_document)

    # 6. Format response using the in-memory dictionary
    db_document["id"] = str(result.inserted_id)
    if "_id" in db_document:
        del db_document["_id"]

    return db_document