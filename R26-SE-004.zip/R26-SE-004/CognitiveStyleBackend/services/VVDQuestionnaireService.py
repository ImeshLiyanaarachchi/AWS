from datetime import datetime
# Note: Rename your MongoDB collection import as needed
from database.connection import vvq_collection

# VVQ Scoring Definitions
# Standard Items: True = 1 point, False = 0 points
STANDARD_QUESTIONS = {2, 5, 7, 11, 14, 15}

# Reverse Items: False = 1 point, True = 0 points
REVERSE_QUESTIONS = {1, 3, 4, 6, 8, 9, 10, 12, 13}

# ==========================================
# 4. SERVICE LOGIC
# ==========================================
async def create_vvq_record(data: dict):
    total_score = 0

    # 1. Process answers just to calculate the score (we won't save these)
    for answer in data.get("answers", []):
        q_id = answer["questionId"]
        raw_val = answer["rawScore"]

        if q_id in STANDARD_QUESTIONS:
            total_score += 1 if raw_val == "True" else 0
        elif q_id in REVERSE_QUESTIONS:
            total_score += 1 if raw_val == "False" else 0

    # 2. Determine Dominant Profile
    if total_score <= 7:
        dominant_profile = "Verbal"
    elif 8 <= total_score <= 11:
        dominant_profile = "Moderate/Intermediatory"
    else:
        dominant_profile = "Visual"

    # 3. Prepare Final Document (PERSISTING ONLY WHAT YOU REQUESTED)
    db_document = {
        "userId": data.get("userId"),
        "dominant_profile": dominant_profile,
        "created_at": datetime.utcnow()
    }

    # 4. Save to Database
    result = await vvq_collection.insert_one(db_document)

    # 5. Format Response for Pydantic (adding the string 'id')
    db_document["id"] = str(result.inserted_id)

    if "_id" in db_document:
        del db_document["_id"]

    return db_document